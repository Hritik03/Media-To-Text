//
//  ViewController.swift
//  SpeechRegonizer
//
//  Created by hb on 18/07/22.
//

import UIKit
import Speech

class ViewController: UIViewController,SFSpeechRecognizerDelegate {
    // MARK: OUTLETS
    @IBOutlet weak var lblColorname: UILabel!
    @IBOutlet weak var viewColour: UIView!
    @IBOutlet weak var lblstartrec: UIButton!
    @IBOutlet weak var lbltext: UILabel!
    let audioUrl = Bundle.main.url(forResource: "Audio", withExtension: "m4a")
    
    // MARK: VARIABLES
    // This will process the audio
    // An AVAudioEngine contains a group of connected AVAudioNodes ("nodes"), each of which performs an audio signal generation, processing, or input/output task.
    let audioEngine = AVAudioEngine()
    
    // Locales which support speech recognition.
    // Note that supported does not mean currently available; some locales may require an internet connection
    let speechRecognizer: SFSpeechRecognizer? = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    
    // A request to recognize speech from arbitrary audio buffers
    let request = SFSpeechAudioBufferRecognitionRequest()
    
    
    // Manage the task
    var recognitionTask: SFSpeechRecognitionTask?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let req = SFSpeechURLRecognitionRequest(url:audioUrl!)
        req.shouldReportPartialResults = true
        if(speechRecognizer?.isAvailable)! {
            speechRecognizer?.recognitionTask(with: req) {
                results , error in
                guard error == nil else {
                    print("Error")
                    return
                }
                guard let results = results else {
                    return
                }
                print(results.bestTranscription)
            }
        }
        else {
            print("recogniser not available")
        }
    }
    
    
    @IBAction func btnStartStoprec(_ sender: Any) {
        self.recordAndRecognizeSpeech()
    }
    
    func recordAndRecognizeSpeech(){
        //Nodes are created separately and attached to the engine.
        let node = audioEngine.inputNode
        // Nodes have input and output busses, which can be thought of as connection points.For example, an effect typically has one input bus and one output bus. A mixertypically has multiple input busses and one output bus.
        let recordingFormat = node.outputFormat(forBus: 0)
        // The engine supports dynamic connection, disconnection and removal of nodes while running, with only minor limitations:
        node.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.request.append(buffer)
        }
        
        // Prepare and start the Recording using audio engine
        audioEngine.prepare()
        do {
            try audioEngine.start()
        } catch {
            return print(error)
        }
        
        //check to make sure the recognizer is avialable for the device and for locale
        guard let myrecognizer = SFSpeechRecognizer() else {
            print("recognizer not Supported")
            return
        }
        if !myrecognizer.isAvailable {
            print("recognizer not available")
            //recognizer is not avilable right now
            return
        }
        
        //Call the recognition task method
        recognitionTask = speechRecognizer?.recognitionTask(with: request, resultHandler: { result, error in
            if let result = result {
                let bestString = result.bestTranscription.formattedString
                self.lbltext.text = bestString.lowercased()
                var laststring:String = ""
                for segment in result.bestTranscription.segments {
                    let indexTo = bestString.index(bestString.startIndex, offsetBy: segment.substringRange.location)
                    print(indexTo)
                    laststring = bestString.substring(from: indexTo)
                    print(laststring)
                }
                self.checkForColor(resultstring:laststring)
                
            } else if let error = error {
                print(error)
            }
        })
        
    }
    
    func checkForColor(resultstring:String) {
        switch resultstring {
        case "red":
            viewColour.backgroundColor = UIColor.red
        case "Red":
            viewColour.backgroundColor = UIColor.red
        case "orange":
            viewColour.backgroundColor = UIColor.orange
        case "Orange":
            viewColour.backgroundColor = UIColor.orange
        case "grey":
            viewColour.backgroundColor = UIColor.gray
        case "Grey":
            viewColour.backgroundColor = UIColor.gray
        case "black":
            viewColour.backgroundColor = UIColor.black
        case "Black":
            viewColour.backgroundColor = UIColor.black
        case "blue":
            viewColour.backgroundColor = UIColor.blue
        case "Blue":
            viewColour.backgroundColor = UIColor.blue
        case "green":
            viewColour.backgroundColor = UIColor.green
        case "Green":
            viewColour.backgroundColor = UIColor.green
        case "pink":
            viewColour.backgroundColor = UIColor.systemPink
        case "Pink":
            viewColour.backgroundColor = UIColor.systemPink
            
        default : break
        }
        
    }
}

